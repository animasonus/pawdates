// Initialize Firebase
var config = {
	apiKey: "AIzaSyD--Nr24BWZcrICe4bd7H3N4MMZe2X2Yl4",
	authDomain: "pawdates.firebaseapp.com",
	databaseURL: "https://pawdates.firebaseio.com",
	storageBucket: "pawdates.appspot.com",
	messagingSenderId: "919306299503"
};

firebase.initializeApp(config);