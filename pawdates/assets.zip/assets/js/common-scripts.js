/*---LEFT BAR ACCORDION----*/
$(function() {
    $('#nav-accordion').dcAccordion({
        eventType: 'click',
        autoClose: true,
        saveState: true,
        disableLink: true,
        speed: 'slow',
        showCount: false,
        autoExpand: true,
//        cookie: 'dcjq-accordion-1',
        classExpand: 'dcjq-current-parent'
    });
});

var Script = function () {


//    sidebar dropdown menu auto scrolling

    jQuery('#sidebar .sub-menu > a').click(function () {
        var o = ($(this).offset());
        diff = 250 - o.top;
        if(diff>0)
            $("#sidebar").scrollTo("-="+Math.abs(diff),500);
        else
            $("#sidebar").scrollTo("+="+Math.abs(diff),500);
    });



//    sidebar toggle

    $(function() {
        function responsiveView() {
            var wSize = $(window).width();
            if (wSize <= 768) {
                $('#container').addClass('sidebar-close');
                $('#sidebar > ul').hide();
            }

            if (wSize > 768) {
                $('#container').removeClass('sidebar-close');
                $('#sidebar > ul').show();
            }
        }
        $(window).on('load', responsiveView);
        $(window).on('resize', responsiveView);
    });

    $('.fa-bars').click(function () {
        if ($('#sidebar > ul').is(":visible") === true) {
            $('#main-content').css({
                'margin-left': '0px'
            });
            $('#sidebar').css({
                'margin-left': '-210px'
            });
            $('#sidebar > ul').hide();
            $("#container").addClass("sidebar-closed");
        } else {
            $('#main-content').css({
                'margin-left': '210px'
            });
            $('#sidebar > ul').show();
            $('#sidebar').css({
                'margin-left': '0'
            });
            $("#container").removeClass("sidebar-closed");
        }
    });

// custom scrollbar
    $("#sidebar").niceScroll({styler:"fb",cursorcolor:"#4ECDC4", cursorwidth: '3', cursorborderradius: '10px', background: '#404040', spacebarenabled:false, cursorborder: ''});

    $("html").niceScroll({styler:"fb",cursorcolor:"#4ECDC4", cursorwidth: '6', cursorborderradius: '10px', background: '#404040', spacebarenabled:false,  cursorborder: '', zindex: '1000'});

// widget tools

    jQuery('.panel .tools .fa-chevron-down').click(function () {
        var el = jQuery(this).parents(".panel").children(".panel-body");
        if (jQuery(this).hasClass("fa-chevron-down")) {
            jQuery(this).removeClass("fa-chevron-down").addClass("fa-chevron-up");
            el.slideUp(200);
        } else {
            jQuery(this).removeClass("fa-chevron-up").addClass("fa-chevron-down");
            el.slideDown(200);
        }
    });

    jQuery('.panel .tools .fa-times').click(function () {
        jQuery(this).parents(".panel").parent().remove();
    });


//    tool tips

    $('.tooltips').tooltip();

//    popovers

    $('.popovers').popover();



// custom bar chart

    if ($(".custom-bar-chart")) {
        $(".bar").each(function () {
            var i = $(this).find(".value").html();
            $(this).find(".value").html("");
            $(this).find(".value").animate({
                height: i
            }, 2000)
        })
    }


}();


/*---PAWDATES COMMON FILES---*/

/*-CHAT.js-*/
function Chat () {
    this.update = updateChat;
    this.send = sendChat;
    this.getState = getStateOfChat;
}

//gets the state of the chat
function getStateOfChat() {
    if(!instanse){
        instanse = true;
        $.ajax({
            type: "POST",
            url: "process.php",
            data: {'function': 'getState', 'file': file},
            dataType: "json",
            success: function(data) {state = data.state;instanse = false;}
        });
    }
}

//Updates the chat
function updateChat() {
    if(!instanse){
        instanse = true;
        $.ajax({
            type: "POST",
            url: "process.php",
            data: {'function': 'update','state': state,'file': file},
            dataType: "json",
            success: function(data) {
                if(data.text){
                    for (var i = 0; i < data.text.length; i++) {
                        $('#chat-area').append($(""+ data.text[i] +""));
                    }
                }
                document.getElementById('chat-area').scrollTop = document.getElementById('chat-area').scrollHeight;
                instanse = false;
                state = data.state;
            }
        });
    }
    else {
        setTimeout(updateChat, 1500);
    }
}

//send the message
function sendChat(message, nickname) {
    updateChat();
    $.ajax({
        type: "POST",
        url: "process.php",
        data: {'function': 'send','message': message,'nickname': nickname,'file': file},
        dataType: "json",
        success: function(data){
            updateChat();
        }
    });
}

/*-CRUD.JS-*/

/*-fbInt.js-*/
// Initialize Firebase
var config = {
    apiKey: "AIzaSyD--Nr24BWZcrICe4bd7H3N4MMZe2X2Yl4",
    authDomain: "pawdates.firebaseapp.com",
    databaseURL: "https://pawdates.firebaseio.com",
    storageBucket: "pawdates.appspot.com",
    messagingSenderId: "919306299503"
};

firebase.initializeApp(config);

/*-MATCH/UNMATCH-*/
function match(userA, userB){
    next();
    Array.prototype.includes();
    var userAPMatches = firebase.database().ref("users/" + userA + "/p_matches");
    var userBPMatches = firebase.database().ref("users/" + userB + "/p_matches");

    userAPMatches.push(userB);
    if (userBPMatches.includes(userA)){
        sendMatchRequest(userB);
    }else{
        userBPMatches.push(userA);
    }
}

/*-NEXT.js-*/
function next() {
    var picList = ["assets/img/smug2.jpg","assets/img/smug3.png","assets/img/smug4.jpg","assets/img/smug5.png","assets/img/usericon.png"];
    imagesrc = document.getElementById("userpic");
    var randomNumber = Math.floor(Math.random()*4);
    imagesrc.src = picList[randomNumber]
}

/*-SIGNIO.js-*/
function signIn() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    firebase.auth().signInWithEmailAndPassword(email, password).catch(function(error) {
        var errorCode = error.code;
        var errormessage = error.message;

        if (errorCode == 'auth/invalid-email') {
            alert("Invalid Email.");
        } else if (errorCode == 'auth/user-disabled') {
            alert("The user corresponding to the given email has been disabled.");
        } else if (errorCode == 'auth/operation-not-allowed') {
            alert("Noah fucked up. Sorry about that.");
        } else if (errorCode == 'auth/user-not-found') {
            alert("No user is registered under this email address");
        } else if (errorCode == 'auth/wrong-password') {
            alert("Incorrect password");
        } else {
            alert(errorMessage);
        }
    });

    isUserSignedIn();
}

function signOut() {
    firebase.auth().signOut();
}

function isUserSignedIn() {
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
            window.location.replace(index.html);
        } else {
            window.location.replace('http://pawdates.firebaseapp.com/404.html');
        }
    });
}

/*-SIGNUP.JS-*/
function signUp() {
    var name = document.getElementsByName("firstname")+" "+document.getElementsByName("lastname");
    var email = document.getElementsByName("email");
    var password = document.getElementsByName("password");
    var confirmPwd = document.getElementsByName("confirmpswrd");

    createNewUserData(name, email, password);
}

/*-WRITESIDEITEM.js-*/
function postSideitem() {
    var sideItem = document.createElement('li');
    var matches = document.getElementsByClassName("matches");
    document.write(sideItem);
    sideItem.innerHTML = '<li class="sidebar-item">\<div id="match_pfp"><img src="pics-n-icons/default_small.jpg"></div>' +
        '\<span id="match_name">Smug Anime Girl</span>\</li>';
    document.body.matches.appendChild(sideItem);
}
window.onload = postSideitem();

/*-WRITETODASHBOARD-*/
function postcard(){
    var cardDiv = document.createElement('div');
    document.write(cardDiv);
    cardDiv.innerHTML= '<div class="wrapper">\<div id="card" class="card" data-id="0">\<div id="card_img" class="card_img">' +
        '\<!-- Image containing obligatory smug anime girl-->' +
        '\<img src="default.jpg" width="155" height="155">\</div>\<div id="smug" class="desc">\<center>' +
        '\Smug Anime Girl<br>\Dogs:<br>\[insert dogs here]\</center>\</div>\</div>\</div>';
    document.body.appendChild(cardDiv);
}
window.onload= postcard();

/*-CABLE.JS-*/
// Action Cable provides the framework to deal with WebSockets in Rails.
// You can generate new channels where WebSocket features live using the rails generate channel command.
//
//= require action_cable
//= require_self
//= require_tree ./channels

(function() {
    this.App || (this.App = {});

    App.cable = ActionCable.createConsumer();

}).call(this);